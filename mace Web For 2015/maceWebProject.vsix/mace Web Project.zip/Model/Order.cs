﻿namespace $safeprojectname$ {
    public class Order {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int OrderAmount { get; set; }
    }
}
